/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package org.adrianposadas.controllers;

import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javax.swing.JOptionPane;
import org.adrianposadas.beans.Clientes;
import org.adrianposadas.db.Conexion;
import org.adrianposadas.system.Main;

public class MenuClientesController implements Initializable {

    private Main escenarioClientes;

    private enum operaciones {
        AGREGAR, ELIMINAR, EDITAR, ACTUALIZAR, CANCELAR, NINGUNO
    }
    private operaciones tipoOperacion = operaciones.NINGUNO;
    private ObservableList<Clientes> listaClientes;

    @FXML
    private Button btnHome;
    @FXML
    private Button btnAgregarCliente;
    @FXML
    private Button btnEditarCliente;
    @FXML
    private Button btnEliminarCliente;
    @FXML
    private Button btnReportesCliente;
    @FXML
    private TextField txtCodigoCliente;
    @FXML
    private TextField txtNitCliente;
    @FXML
    private TextField txtNombreCliente;
    @FXML
    private TextField txtApellidoCliente;
    @FXML
    private TextField txtDireccionCliente;
    @FXML
    private TextField txtTelefonoCliente;
    @FXML
    private TextField txtCorreoCliente;
    @FXML
    private ImageView imgAgregarIcono;
    @FXML
    private ImageView imgEditarIcono;
    @FXML
    private ImageView imgEliminarIcono;
    @FXML
    private ImageView imgReportesIcono;
    @FXML
    private TableColumn colCodigoCliente;
    @FXML
    private TableColumn colNitCliente;
    @FXML
    private TableColumn colNombreCliente;
    @FXML
    private TableColumn colApellidoCliente;
    @FXML
    private TableColumn colDireccionCliente;
    @FXML
    private TableColumn colTelefonoCliente;
    @FXML
    private TableColumn colCorreoCliente;
    @FXML
    private TableView tblClientes;

    @Override
    public void initialize(URL url, ResourceBundle resources) {
        cargarDatos();
    }

    public void cargarDatos() {
        tblClientes.setItems(getClientes());
        colCodigoCliente.setCellValueFactory(new PropertyValueFactory<Clientes, Integer>("codigoCliente"));
        colNitCliente.setCellValueFactory(new PropertyValueFactory<Clientes, String>("NITCliente"));
        colNombreCliente.setCellValueFactory(new PropertyValueFactory<Clientes, String>("nombreCliente"));
        colApellidoCliente.setCellValueFactory(new PropertyValueFactory<Clientes, Integer>("apellidoCliente"));
        colDireccionCliente.setCellValueFactory(new PropertyValueFactory<Clientes, Integer>("direccionCliente"));
        colTelefonoCliente.setCellValueFactory(new PropertyValueFactory<Clientes, Integer>("telefonoCliente"));
        colCorreoCliente.setCellValueFactory(new PropertyValueFactory<Clientes, Integer>("correoCliente"));
    }

    public ObservableList<Clientes> getClientes() {
        ArrayList<Clientes> lista = new ArrayList<>();
        try {
            PreparedStatement procedimiento = Conexion.getInstance().getConnection().prepareCall("{call sp_ListarClientes()}");
            ResultSet resultado = procedimiento.executeQuery();
            while (resultado.next()) {
                lista.add(new Clientes(resultado.getInt("codigoCliente"),
                        resultado.getString("NITCliente"),
                        resultado.getString("nombreCliente"),
                        resultado.getString("apellidoCliente"),
                        resultado.getString("direccionCliente"),
                        resultado.getString("telefonoCliente"),
                        resultado.getString("correoCliente")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return listaClientes = FXCollections.observableArrayList(lista);
    }

    public void agregar() {
        switch (tipoOperacion) {
            case NINGUNO:
                activarControles();
                btnAgregarCliente.setText("Guardar");
                btnEditarCliente.setText("Cancelar");
                btnEliminarCliente.setDisable(true);
                btnReportesCliente.setDisable(true);
                imgAgregarIcono.setImage(new Image("/org/adrianposadas/image/guardar.png"));
                imgEditarIcono.setImage(new Image("/org/adrianposadas/image/cancelar.png"));
                tipoOperacion = operaciones.ACTUALIZAR;
                break;
            case ACTUALIZAR:
                guardar();
                desactivarControles();
                limpiarControles();
                btnAgregarCliente.setText("Agregar");
                btnEditarCliente.setText("Editar");
                btnEliminarCliente.setDisable(false);
                btnReportesCliente.setDisable(false);
                imgAgregarIcono.setImage(new Image("/org/adrianposadas/images/business_application_addmale_useradd_insert_add_user_client_2312.png"));
                imgEliminarIcono.setImage(new Image("/org/adrianposadas/images/delete_delete_deleteusers_delete_male_user_maleclient_2348.png"));
                tipoOperacion = operaciones.NINGUNO;
                break;
        }
    }

    public void desactivarControles() {
        txtCodigoCliente.setEditable(false);
        txtNitCliente.setEditable(false);
        txtNombreCliente.setEditable(false);
        txtApellidoCliente.setEditable(false);
        txtDireccionCliente.setEditable(false);
        txtTelefonoCliente.setEditable(false);
        txtCorreoCliente.setEditable(false);
    }
    
    public void activarControles() {
        txtCodigoCliente.setEditable(true);
        txtNitCliente.setEditable(true);
        txtNombreCliente.setEditable(true);
        txtApellidoCliente.setEditable(true);
        txtDireccionCliente.setEditable(true);
        txtTelefonoCliente.setEditable(true);
        txtCorreoCliente.setEditable(true);
    }

    public void limpiarControles() {
        txtCodigoCliente.clear();
        txtNitCliente.clear();
        txtNombreCliente.clear();
        txtApellidoCliente.clear();
        txtDireccionCliente.clear();
        txtTelefonoCliente.clear();
        txtCorreoCliente.clear();
    }
    
    public void guardar(){
        Clientes registro = new Clientes();
        registro.setCodigoCliente(Integer.parseInt(txtCodigoCliente.getText()));
        registro.setNitCliente(txtNitCliente.getText());
        registro.setNombreCliente(txtNombreCliente.getText());
        registro.setApellidoCliente(txtApellidoCliente.getText());
        registro.setDireccionCliente(txtDireccionCliente.getText());
        registro.setTelefonoCliente(txtTelefonoCliente.getText());
        registro.setCorreoCliente(txtCorreoCliente.getText());
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConnection().prepareCall("{call sp_AgregarClientes(?, ?, ?, ?, ?, ?, ?)}");
            procedimiento.setInt(1, registro.getCodigoCliente());
            procedimiento.setString(2, registro.getNitCliente());
            procedimiento.setString(3, registro.getNombreCliente());
            procedimiento.setString(4, registro.getApellidoCliente());
            procedimiento.setString(5, registro.getDireccionCliente());
            procedimiento.setString(6, registro.getTelefonoCliente());
            procedimiento.setString(7, registro.getCorreoCliente());
            procedimiento.execute();
            listaClientes.add(registro);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public void seleccionarElemento (){
        txtCodigoCliente.setText(String.valueOf(((Clientes)tblClientes.getSelectionModel().getSelectedItem()).getCodigoCliente()));
        txtNitCliente.setText(((Clientes)tblClientes.getSelectionModel().getSelectedItem()).getNitCliente());
        txtNombreCliente.setText(((Clientes)tblClientes.getSelectionModel().getSelectedItem()).getNombreCliente());
        txtApellidoCliente.setText(((Clientes)tblClientes.getSelectionModel().getSelectedItem()).getApellidoCliente());
        txtDireccionCliente.setText(((Clientes)tblClientes.getSelectionModel().getSelectedItem()).getDireccionCliente());
        txtTelefonoCliente.setText(((Clientes)tblClientes.getSelectionModel().getSelectedItem()).getTelefonoCliente());
        txtCorreoCliente.setText(((Clientes)tblClientes.getSelectionModel().getSelectedItem()).getCorreoCliente());
    }
    
    public void eliminar(){
        switch(tipoOperacion){
            case ACTUALIZAR:
                desactivarControles();
                limpiarControles();
                btnAgregarCliente.setText("Agregar");
                btnEditarCliente.setText("Agregar");
                btnEliminarCliente.setText("Eliminar");
                btnReportesCliente.setText("Reportes");
                btnAgregarCliente.setDisable(false);
                btnEditarCliente.setDisable(false);
                btnEliminarCliente.setDisable(false);
                btnReportesCliente.setDisable(false);
                imgAgregarIcono.setImage(new Image("---------"));
                imgEliminarIcono.setImage(new Image("---------"));
                tipoOperacion = operaciones.NINGUNO;
                break;
            default:
                if(tblClientes.getSelectionModel().getSelectedItem() != null){
                    int ans = JOptionPane.showConfirmDialog(null, "Confirmar eliminacion",
                            "Elminar Clientes", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE);
                    if(ans == JOptionPane.YES_NO_OPTION){
                        try{
                            PreparedStatement procedimiento = Conexion.getInstance().getConnection().prepareCall("{call sp_EliminarCliente(?)}");
                            procedimiento.setInt(1, ((Clientes)tblClientes.getSelectionModel().getSelectedItem()).getCodigoCliente());
                            procedimiento.execute();
                            listaClientes.remove(tblClientes.getSelectionModel().getSelectedItem());
                        }catch (Exception e){
                            e.printStackTrace();
                        }
                    }
                }else{
                    JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento");
                }
        }
    }
    
    public void editar(){
        switch (tipoOperacion){
            case NINGUNO:
                if(tblClientes.getSelectionModel().getSelectedItem() != null){
                    btnEditarCliente.setText("Actualizar");
                    btnEliminarCliente.setText("Cancelar");
                    btnReportesCliente.setDisable(true);
                    btnAgregarCliente.setDisable(true);
                    imgEditarIcono.setImage(new Image("/org/adrianposadas/images/guardar.png"));
                    imgEliminarIcono.setImage(new Image("/org/adrianposadas/images/cancelar.png"));
                    activarControles();
                    txtCodigoCliente.setEditable(false);
                    tipoOperacion = operaciones.ACTUALIZAR;
                }else{
                    JOptionPane.showMessageDialog(null, "Debe seleccionar un elemento");
                }
                break;
            case ACTUALIZAR:
                actualizar();
                btnEditarCliente.setText("Editar");
                btnEliminarCliente.setText("Eliminar");
                btnAgregarCliente.setDisable(false);
                btnReportesCliente.setDisable(false);
                imgEditarIcono.setImage(new Image("/org/adrianposadas/images/businessapplication_edit_male_user_thepencil_theclient_negocio_2321.png"));
                imgEliminarIcono.setImage(new Image("/org/adrianposadas/images/eliminar.png"));
                desactivarControles();
                limpiarControles();
                tipoOperacion = operaciones.NINGUNO;
                cargarDatos();
                break;
        }
    }
    public void setEscenarioPrincipal(Main escenarioClientes) {
        this.escenarioClientes = escenarioClientes;
    }
    
    public void actualizar(){
        try{
            PreparedStatement procedimiento = Conexion.getInstance().getConnection().prepareCall("{call sp_EditarCliente(?, ?, ?, ?, ?, ?, ?)}");
            Clientes registro = (Clientes) tblClientes.getSelectionModel().getSelectedItem();
            registro.setNitCliente(txtNitCliente.getText());
            registro.setNombreCliente(txtNombreCliente.getText());
            registro.setApellidoCliente(txtApellidoCliente.getText());
            registro.setDireccionCliente(txtDireccionCliente.getText());
            registro.setTelefonoCliente(txtTelefonoCliente.getText());
            registro.setCorreoCliente(txtCorreoCliente.getText());
            procedimiento.setInt(1, registro.getCodigoCliente());
            procedimiento.setString(2, registro.getNitCliente());
            procedimiento.setString(3, registro.getNombreCliente());
            procedimiento.setString(4, registro.getApellidoCliente());
            procedimiento.setString(5, registro.getDireccionCliente());
            procedimiento.setString(6, registro.getTelefonoCliente());
            procedimiento.setString(7, registro.getCorreoCliente());
            procedimiento.execute();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @FXML
    public void clickClientesController(ActionEvent event) {
        if (event.getSource() == btnHome) {
            escenarioClientes.menuPrincipalView();
        }

    }
}
